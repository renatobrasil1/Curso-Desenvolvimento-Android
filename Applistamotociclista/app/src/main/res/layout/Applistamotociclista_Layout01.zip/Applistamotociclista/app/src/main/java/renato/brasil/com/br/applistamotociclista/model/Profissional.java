package renato.brasil.com.br.applistamotociclista.model;

public class Profissional {

    private String nomeDoprofissionalDesejado;

    public Profissional(String nomeDoprofissionalDesejado) {
        this.nomeDoprofissionalDesejado = nomeDoprofissionalDesejado;

    }

    public String getNomeDoprofissionalDesejado() {return nomeDoprofissionalDesejado;}

    public void setNomeDoprofissionalDesejado(String nomeDoprofissionalDesejado) {
        this.nomeDoprofissionalDesejado = nomeDoprofissionalDesejado;
    }
}
